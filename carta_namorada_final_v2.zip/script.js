function mostrarCarta() {
  let carta = document.getElementById("carta");
  carta.classList.remove("oculto");
}

// Criar corações animados
function createHeart() {
  const heart = document.createElement("div");
  heart.classList.add("heart");
  heart.innerHTML = "❤️";
  heart.style.left = Math.random() * 100 + "vw";
  heart.style.top = "100vh";
  heart.style.animationDuration = Math.random() * 2 + 3 + "s";
  heart.style.position = "absolute";
  heart.style.fontSize = Math.random() * 20 + 10 + "px";

  document.getElementById("hearts-container").appendChild(heart);

  setTimeout(() => {
    heart.remove();
  }, 4000);
}

setInterval(createHeart, 500);